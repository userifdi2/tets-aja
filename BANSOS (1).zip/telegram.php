<?php
$telegram_id = "6762538392";
$id_bot = "6303322859:AAFTNBdgDEGRULvu8rXWtaFccRtyCXGFzZw";
?>
